package com.example.pongstage1;

import com.example.pongstage1.Controller.collisionControls;
import com.example.pongstage1.Model.Ball;
import com.example.pongstage1.Model.Racket;
import javafx.application.Platform;
import javafx.scene.paint.Color;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class CollisionDetectionTest {
    private collisionControls collision;
    private Ball ball;
    private Racket player1Racket, player2Racket;
    // example stages
    private final double stageWidth = 600;
    private final double stageHeight = 400;


    @BeforeAll
    public static void setUpBeforeClass() throws Exception {
        if (!Platform.isFxApplicationThread()) {
            Platform.startup(() -> {
            });
        }
    }
    @BeforeEach
    public void setUp() {
        // Initialize the ball at the center of the stage
        ball = new Ball(10, Color.WHITE);
        ball.getVisualRepresentation().setCenterX(stageWidth / 2);
        ball.getVisualRepresentation().setCenterY(stageHeight / 2);

        // Initialize player 1 and 2 rackets at positions
        player1Racket = new Racket(10, stageHeight / 2 - 50, 10, 100, Color.WHITE);
        player2Racket = new Racket(stageWidth - 20, stageHeight / 2 - 50, 10, 100, Color.WHITE);

        // Initialize collision controls with the ball, rackets, and stage dimensions
        collision = new collisionControls(ball, player1Racket, player2Racket, stageWidth, stageHeight);
    }

    @Test
    public void testPlayer2Scores() {
        // Set the ball's position to simulate player 2 scoring
        ball.getVisualRepresentation().setCenterX(5); // Ball is on the left edge
        assertTrue(collision.player2Scores(), "Player 2 should score");

        // Set the ball's position to simulate player 2 not scoring
        ball.getVisualRepresentation().setCenterX(stageWidth / 2); // Ball is in the center
        assertFalse(collision.player2Scores(), "Player 2 should not score");
    }
    @Test
    public void testCollisionWithTopWall() {
        // Simulate ball moving upwards towards the top wall
        ball.getVisualRepresentation().setCenterY(ball.getVisualRepresentation().getRadius());
        ball.setDy(-5); // indicates upward movement

        collision.checkCollisions();

        // After collision, the ball should move downwards
        assertTrue(ball.getDy() > 0, "After collision with the top wall, dy should be positive.");
    }

    @Test
    public void testCollisionWithBottomWall() {
        // Simulate ball moving downwards towards the bottom wall
        ball.getVisualRepresentation().setCenterY(stageHeight - ball.getRadius());
        ball.setDy(5); // Positive dy indicates downward movement


        collision.checkCollisions();

        // After collision, the ball should move upwards
        assertTrue(ball.getDy() < 0, "After collision with the bottom wall, dy should be negative.");
    }

    @Test
    public void testCollisionWithPlayer1Racket() {
        // Simulate ball moving towards player 1's racket
        ball.getVisualRepresentation().setCenterX(player1Racket.getX() + player1Racket.getWidth() + ball.getRadius());
        ball.getVisualRepresentation().setCenterY(player1Racket.getY());
        ball.setDx(-5); // Negative dx indicates leftward movement

        collision.checkCollisions();

        // After collision, the ball should move to the right
        assertTrue(ball.getDx() > 0, "After collision with player 1's racket, dx should be positive.");
    }

    @Test
    public void testCollisionWithPlayer2Racket() {
        // Simulate ball moving towards player 2 racket
        ball.getVisualRepresentation().setCenterX(player2Racket.getX() - ball.getRadius());
        ball.getVisualRepresentation().setCenterY(player2Racket.getY());
        ball.setDx(5); // Positive dx indicates right ward movement

        collision.checkCollisions();

        // After collision the ball should move to the left
        assertTrue(ball.getDx() < 0, "After collision with player 2's racket, dx should be negative.");
    }


}
