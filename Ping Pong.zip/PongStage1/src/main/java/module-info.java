
module com.example.pongstage1 {
    requires javafx.controls;
    requires javafx.fxml;
    requires javafx.graphics;
    requires java.sql;


    opens com.example.pongstage1.Model to org.junit.jupiter.api, org.junit.platform.commons;
    opens com.example.pongstage1 to javafx.fxml;
    exports com.example.pongstage1.View to javafx.graphics;
}